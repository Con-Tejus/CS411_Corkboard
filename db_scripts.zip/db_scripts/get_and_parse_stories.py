import requests as requests
import json as json
import pandas as pd

API_ENDPOINT = 'https://newsapi.org/v2/everything'
API_KEY = '0dafed3a04d0429ea68e896cb872380b'
DICT_KEY = 'articles'
START_DATE = '2019-04-05'
SOURCE_LIST = []
#COMPANY_TICKER_LIST = [('Google', 'GOOG'), ('Apple', 'AAPL'), ('Microsoft', 'MSFT'),
#                       ('Facebook', 'FB'), ('Exxon Mobil', 'XOM')
#                      ]

COMPANY_TICKER_LIST = [('Advanced Micro Devices', 'AMD'), ('Snapchat', 'SNAP'), ('Sirius XM', 'SIRI'),
                       ('Twitter', 'TWTR'), ('Nvidia', 'NVDA')
                      ]

#COMPANY_TICKER_LIST = [('Budweiser', 'BUD'), ('Amazon', 'AMZN'), ('Square', 'SQ'),
#                       ('Alibaba', 'BABA'), ('Tesla', 'TSLA')
 #                     ]

#COMPANY_TICKER_LIST = [('Intel', 'INTC')]
#TICKERS             = ['AMD', 'SNAP', 'SIRI', 'TWTR', 'NVDA']

STORIES_FILE_NAME = 'stories_data.csv'

def get_story_data(company, ticker, source_list, date_string):
    source_string = ','.join(str(e) for e in source_list)

    params = {}
    #params['sources'] = source_string
    params['from'] = date_string
    params['language'] = 'en'
    params['q'] = 'text=' + company
    params['apiKey'] = API_KEY

    r = requests.get(API_ENDPOINT, params=params)

    print(r.url)
    print(r.status_code)
    #print(r.content)

    story_json = r.json()

    for curr_line in story_json['articles']:
        if curr_line['source']['id'] == None:
            curr_line['source']['id'] = ""


    with open('test_file.json', 'w') as f:
        json.dump(story_json, f)

    return story_json

def repalce_nulls():
    pass

def parse_stories(data, ticker, key):
    stories_list = data['articles']
    df = pd.DataFrame()

    for curr_story in stories_list:
        flattened_curr_story = pd.io.json.json_normalize(curr_story)
        df = df.append(flattened_curr_story[['source.name', 'title', 'url', 'publishedAt']])

    df['ticker'] = ticker
    df['score'] = 0
    df.insert(0,'dummy','')

    return df

def create_csv(df, path):
    output = df.to_csv(index=False, header=False, encoding = 'utf-8')

    with open(path, 'w') as f:
        f.write(output)


def get_all_stories(company_ticker_list):
    df = pd.DataFrame()
    for curr_company, curr_ticker in company_ticker_list:
        data = get_story_data(curr_company, curr_ticker, SOURCE_LIST, START_DATE)
        df = df.append(parse_stories(data, curr_ticker, DICT_KEY))

    create_csv(df, STORIES_FILE_NAME)



if __name__ == '__main__':
    get_all_stories(COMPANY_TICKER_LIST)
