import requests as requests
import json as json
import time
import numpy as np
import pandas as pd

API_ENDPOINT        = 'https://www.alphavantage.co/query'
#API_KEY             = 'JX96H2EAVZASC6R7'
API_KEY             = 'C4DPJLANM6Y1JY2W'
TIME_SERIES_KEY     = 'Time Series (Daily)'
TS_FILE_NAME        = 'time_series_data.csv'
#TICKERS             = ['GOOG', 'AAPL', 'MSFT', 'XOM', 'FB']
#TICKERS             = ['AMD', 'SNAP', 'SIRI', 'TWTR', 'NVDA']
TICKERS		    = ['INTC', 'TSLA', 'BUD', 'AMZN', 'BABA'] #got rid of SQ for INTC real quick
def get_request_data(ticker):
    params = {}
    params['function'] = 'TIME_SERIES_DAILY'
    params['symbol'] = ticker
    params['outputsize'] = 'full'
    params['apikey'] = API_KEY


    r = requests.get(API_ENDPOINT, params=params)

    print(r.url)
    print(r.status_code)

    return r.json()

def parse_price(data_dict, ticker, key):
    df = pd.DataFrame.from_dict(data_dict[key], orient='index')

    df.index.name = 'date'
    df.reset_index(inplace=True)

    df.columns = ['date', 'open', 'high', 'low', 'close', 'volume']

    df['ticker'] = ticker

    return df[['date', 'ticker', 'open']]

def create_csv(df, path):
    output = df.to_csv(index=False, header=False)

    with open(path, 'w') as f:
        f.write(output)


def get_all_prices(tickers):
    df = pd.DataFrame()
    for curr_ticker in tickers:
        data = get_request_data(curr_ticker)
        df = df.append(parse_price(data, curr_ticker, TIME_SERIES_KEY))

    create_csv(df, TS_FILE_NAME)

if __name__ == "__main__":
    get_all_prices(TICKERS)
