import pymysql
import pandas as pd
import numpy
import sys

def fetchPricesByTicker(tickler, sim, positivity):
    '''
    This function load a csv file to MySQL table according to
    the load_sql statement.
    '''
    host = 'localhost'
    user = 'corkboard_cody'
    password = 'thisisapassword'
    select_sql = 'select corkboard_DB.Prices.price, corkboard_DB.Stories.positivity From corkboard_DB.Prices left outer join corkboard_DB.Stories on corkboard_DB.Prices.ticker like corkboard_DB.Stories.ticker AND corkboard_DB.Prices.date = date(corkboard_DB.Stories.date) where corkboard_DB.Prices.ticker like \''+ticker+'\' and corkboard_DB.Prices.date between CURRENT_DATE - INTERVAL 200 DAY AND NOW() ORDER BY corkboard_DB.Prices.date'
    #OLD 200 DAY query
    #'select * from corkboard_DB.Prices where ticker like \'' + tickler + '\' and date BETWEEN CURRENT_DATE - INTERVAL 200 DAY AND NOW()'
    '''select corkboard_DB.Prices.price, corkboard_DB.Stories.positivity From corkboard_DB.Prices left outer join corkboard_DB.Stories on corkboard_DB.Prices.ticker
    like Stories.ticker AND Prices.date = date(Stories.date)
    where Prices.ticker like 'AAPL' and Prices.date between CURRENT_DATE - INTERVAL 200 DAY AND NOW() ORDER BY Prices.date
    '''
    try:
        con = pymysql.connect(host='localhost',
                                user='corkboard_cody',
                                password='thisisapassword',
                                autocommit=True,
                                local_infile=1)
        print('Connected to DB: {}'.format(host))
        # Create cursor and execute Load SQL
        cursor = con.cursor()
        cursor.execute(select_sql)
        print('Succuessfully executed the select query.')
        rows = cursor.fetchall()
        con.close()
        new_rows = []
        for row in rows:
                if(row[1] == None):
                        new_rows.append((row[0],0))
                else:
                        new_rows.append(row)
        print(new_rows)
        if(sim):
            temp1 = new_rows[-1]
            temp2 = new_rows[-2]
            temp3 = new_rows[-3]
            del new_rows[-1]
            del new_rows[-2]
            del new_rows[-3]
            new_rows.append((temp3[0],positivity))
            new_rows.append((temp2[0],positivity))
            new_rows.append((temp1[0],positivity))
        print(new_rows)
    except Exception as e:
        print('Error: {}'.format(str(e)))
        sys.exit(1)

# Execution Example
#load_sql = "LOAD DATA LOCAL INFILE '/home/corkboard/db_scripts/"+sys.argv[1]+"' INTO TABLE corkboard_DB.Stories FIELDS TERMINATED BY ',' ENCLOSED BY '\"' IGNORE 0 LINES;"

ticker = 'AAPL'
fetchPricesByTicker(ticker,True, 0.9)
