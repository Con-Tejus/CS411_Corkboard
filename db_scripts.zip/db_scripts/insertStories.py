import pymysql
import pandas as pd
import sys

def csv_to_mysql(load_sql, host, user, password):
    '''
    This function load a csv file to MySQL table according to
    the load_sql statement.
    '''
    try:
        con = pymysql.connect(host='localhost',
                                user='corkboard_cody',
                                password='thisisapassword',
                                autocommit=True,
                                local_infile=1)
        print('Connected to DB: {}'.format(host))
        # Create cursor and execute Load SQL
        cursor = con.cursor()
        cursor.execute(load_sql)
        print('Succuessfully loaded the table from csv.')
        con.close()

    except Exception as e:
        print('Error: {}'.format(str(e)))
        sys.exit(1)

# Execution Example
load_sql = "LOAD DATA LOCAL INFILE '/home/corkboard/db_scripts/"+sys.argv[1]+"' INTO TABLE corkboard_DB.Stories FIELDS TERMINATED BY ',' ENCLOSED BY '\"' IGNORE 0 LINES;"
host = 'localhost'
user = 'corkboard_cody'
password = 'thisisapassword'
csv_to_mysql(load_sql, host, user, password)




'''
import csv
import MySQLdb

mydb = MySQLdb.connect(host='localhost',
    user='corkboard_cody',
    passwd='thisisapassword',
    db='corkboard_DB')
cursor = mydb.cursor()

with open('prices_testdata.csv', 'r') as f:
        for row in f:
                cursor.execute("INSERT INTO Prices(date,ticker,price) VALUES('%s','%s', '%s')",  [row])
#close the connection to the database.
mydb.commit()
cursor.close()
print("Done")
'''
