from django.shortcuts import render
from catalog.models import Simulations,AuthUser,Follows,Stories,Prices
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from .lstm import fetchPricesByTicker
from .sent_analysis import load_and_predict_sent
#from bitly_api import bitly_api
# Create your views here.
#API_USER = "codybecker63@gmail.com"
#API_KEY = "6536c7212b1936205a8112b32fd738780fdf40e6"

#short = bitlyapi.BitLy(API_USER,API_KEY)

def index(request):
	
	num_users = AuthUser.objects.all().count()	
	context = {
		'num_users': num_users
	}

	return render(request, 'catalog/index.html', context = context)

def login(request):
	context = {
	
	}
	
	return render(request,'login.html', context = context)


#@login_required
def portfolio(request):
        ticker_list = []
        display_ticker = []
        prices = []
        price_tickers = []
        save_flag = False
        if(Prices.objects.all().count()):
                prices = Prices.objects.all()
                for price in prices:
                    if(price.ticker not in price_tickers):
                        price_tickers.append(price.ticker)

        if(request.method =='POST' and ('enter' in request.POST) ):
                if(request.POST.get('stocks')):
                        stock = request.POST.get('stocks')
                        if(Follows.objects.filter(username = request.user).count()):
                            for check in Follows.objects.filter(username = request.user):
                                if(stock == check.ticker):
                                    context = {'ticker': "That stock is already included in your portfolio!"}
                                    return render(request,'catalog/portfolio.html', context = context)
                                save_flag = True
                        if(save_flag or (Follows.objects.filter(username = request.user).count() == 0)):
                            follow = Follows()
                            follow.username = request.user
                            follow.ticker = stock
                            follow.save()
	
        else:
                display_ticker = "Please add a ticker!"

        if(request.method =='POST' and ('clear' in request.POST)):
            if(request.POST.get('stocks')):
                stock = request.POST.get('stocks')
                if(Follows.objects.filter(username = request.user).count()):
                    for check in Follows.objects.filter(username = request.user):
                        if(stock == check.ticker):
                            the_deleted = Follows.objects.filter(username = request.user, ticker = stock)
                            the_deleted.delete()
                            #check.delete()           
                            #context = {'ticker': check}
                            #return render(request, 'catalog/portfolio.html', context = context)

        if(Follows.objects.filter(username = request.user).count()):
                display_ticker = (Follows.objects.filter(username = request.user))
                for ticker in display_ticker:
                        ticker_list.append(ticker.ticker)
                display_ticker = ticker_list
        else:
                display_ticker = "please add a ticker!"

        context = {
        'ticker': display_ticker,
        'display_tickers': price_tickers
        }

        return render(request,'catalog/portfolio.html', context = context)

#@login_required
def projections(request):
	followed_tickers = []
	url = []
	if(Follows.objects.filter(username = request.user).count()):
		followed = Follows.objects.filter(username = request.user)
		for follower in followed:
			followed_tickers.append(follower.ticker)
		context = {'tickers': followed_tickers}
	else:
		followed_tickers.append("Add some stocks to your portfolio!")
		context = {'tickers': followed_tickers}
	if(request.method == 'POST'):
		ticker = request.POST.get('stocks')
		fetchPricesByTicker.main(ticker,False,0)
		url.append('projection_images/')
		url.append(ticker)
		url.append('_graph.png')
		url = ''.join(url)		
	else:
		url = 'projection_images/corkboard_default.png'	
	context = {'url': url,
		   'tickers': followed_tickers}
	return render(request,'catalog/projections.html', context = context)

#@login_required
def stories(request):
	followed_tickers = []
	url = []
	title = []
	if(Follows.objects.filter(username = request.user).count()):
		followed = Follows.objects.filter(username = request.user)
		for follower in followed:
			followed_tickers.append(follower.ticker)
	else:
		followed_tickers = "Follow some stocks first!"
		url = "No stories found"
		title = "No stories found"
		context = {
        	'story_url': url,
        	'story_title': title,
        	'ticker_effected': followed_tickers
        	}
		return render(request,'catalog/stories.html', context = context)
	if(request.method =='POST' and ('get_stories' in request.POST) ):
		if(Stories.objects.filter(ticker = request.POST.get('stocks')).count()):
			for dis_story in Stories.objects.filter(ticker = request.POST.get('stocks')):
				story = dis_story
				#small_url = short.shorten(longUrl=story.url)
				url.append((story.url,story.title))
	if(len(url) == 0 and len(title) == 0):
		url = "No stories found"
		title = "No stories found"
	context = {
	'story_url': url,
	'ticker_effected': followed_tickers
        }

	return render(request,'catalog/stories.html', context = context)


def simulations(request):
	prices = []
	price_tickers = []
	url = []
	headline = ""
	if(Prices.objects.all().count()):
                prices = Prices.objects.all()
                for price in prices:
                    if(price.ticker not in price_tickers):
                        price_tickers.append(price.ticker)	
	if(request.method == 'POST' and ('simulate' in request.POST)):
		if(request.POST.get('stocks') and request.POST.get('source_id')):
			#simulation = Simulations()
			if(Simulations.objects.filter(sim_user = request.user).count()):
				simulation = Simulations.objects.get(sim_user = request.user)
				headline = request.POST.get('source_id')
				headline = headline.lower()
				simulation.positivity = load_and_predict_sent.main(headline)#0 for now but will call function after
				simulation.sourceid = request.POST.get('source_id')
				simulation.tickereffected = request.POST.get('stocks')
				simulation.sim_user = request.user
			else:
				simulation = Simulations()
				headline = request.POST.get('source_id')
				headline = headline.lower()
				simulation.positivity = load_and_predict_sent.main(headline) # cll function to assign positivity after
				simulation.sourceid = request.POST.get('source_id')
				simulation.tickereffected = request.POST.get('stocks')
				simulation.sim_user = request.user
		

			simulation.save()

			#sim = Simulations.objects.get(sim_user = request.user)
			positivity = simulation.positivity
			ticker = simulation.tickereffected
			source = simulation.sourceid
			
			fetchPricesByTicker.main(ticker,True,positivity*(-1))
			url.append('projection_images/')
			url.append(ticker)
			url.append('_graph.png')
			url = ''.join(url)
		else:
			positivity = 0
			ticker = "Enter a simulation!"
			source = "Enter a simulation!"
			url = 'projection_images/corkboard_default.png'
			
	else:
		positivity = 0
		ticker = "Enter a simulation!"
		source = "Enter a simulation!"
		url = 'projection_images/corkboard_default.png'
	if(request.method == 'POST' and ('clear' in request.POST)): 
		if(Simulations.objects.filter(sim_user = request.user).count()):
			simulation = Simulations.objects.get(sim_user = request.user)
			simulation.delete()
	
        #number_check = sim.positivity
	context = {
                'positivity': positivity,
                'ticker': ticker,
		'source': source,
		'display_tickers':price_tickers,
		'url':url
	}
	
	return render(request,'catalog/simulations.html', context = context)

class signup(generic.CreateView):
	form_class = UserCreationForm
	success_url = reverse_lazy('login')
	template_name = 'signup.html'
