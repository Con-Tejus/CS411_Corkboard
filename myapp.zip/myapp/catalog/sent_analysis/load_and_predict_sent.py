import pickle
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import CountVectorizer

LOG_MODEL_PATH = '/home/corkboard/myapp/catalog/sent_analysis/log_model.pkl'
BOW_MODEL_PATH = '/home/corkboard/myapp/catalog/sent_analysis/BOW_model.pkl'

def get_predictions(headline_vector):
    with open(LOG_MODEL_PATH, 'rb') as f:
        model = pickle.load(f)

    probabilities = model.predict_proba(headline_vector)

    return probabilities

def create_vector(headline):
    with open(BOW_MODEL_PATH, 'rb') as f:
        vectorizer = pickle.load(f)

    vocab_dict = vectorizer.vocabulary_

    headline_vector = np.zeros(len(vocab_dict), dtype=float)
    headline_array = headline.split()

    for word in headline_array:
        if word in vocab_dict:
            print("True")
            headline_vector[vocab_dict[word]] += 1
            print(vocab_dict[word])

    headline_vector = np.reshape(headline_vector, (1, -1))
    return headline_vector

def scale_positivity(predictions):
    positivity = predictions[0, 1]
    positivity = (positivity - 0.5) * 2

    return positivity
    
def main(headline):
    headline_vector = create_vector(headline)
    predictions = get_predictions(headline_vector)
    positivity = scale_positivity(predictions)
    return positivity
