from django.contrib import admin

# Register your models here.
'''
from catalog.models import Users,Effects,Follows,Prices,Simulations,Stories

admin.site.register(Users)
admin.site.register(Effects)
admin.site.register(Follows)
admin.site.register(Prices)
admin.site.register(Simulations)
admin.site.register(Stories)
'''
