import pymysql
import pandas as pd
import sys
import torch
import numpy as np 
import matplotlib.pyplot as plt
from .lstm import LSTM

MODEL_PATH = '/home/corkboard/myapp/catalog/lstm/lstm_model.pt'
GRAPH_PATH = '/home/corkboard/myapp/static_files/projection_images/'

def fetchPricesByTicker(ticker, sim, positivity):
    '''
    This function load a csv file to MySQL table according to
    the load_sql statement.
    '''
    host = 'localhost'
    user = 'corkboard_cody'
    password = 'thisisapassword'
    select_sql = 'select corkboard_DB.Prices.price, corkboard_DB.Stories.positivity From corkboard_DB.Prices left outer join corkboard_DB.Stories on corkboard_DB.Prices.ticker like corkboard_DB.Stories.ticker AND corkboard_DB.Prices.date = date(corkboard_DB.Stories.date) where corkboard_DB.Prices.ticker like \''+ticker+'\' and corkboard_DB.Prices.date between CURRENT_DATE - INTERVAL 200 DAY AND NOW() ORDER BY corkboard_DB.Prices.date'
    #OLD 200 DAY query
    #'select * from corkboard_DB.Prices where ticker like \'' + tickler + '\' and date BETWEEN CURRENT_DATE - INTERVAL 200 DAY AND NOW()'
    '''select corkboard_DB.Prices.price, corkboard_DB.Stories.positivity From corkboard_DB.Prices left outer join corkboard_DB.Stories on corkboard_DB.Prices.ticker
    like Stories.ticker AND Prices.date = date(Stories.date)
    where Prices.ticker like 'AAPL' and Prices.date between CURRENT_DATE - INTERVAL 200 DAY AND NOW() ORDER BY Prices.date
    '''
    try:
        con = pymysql.connect(host='localhost',
                                user='corkboard_cody',
                                password='thisisapassword',
                                autocommit=True,
                                local_infile=1)
        print('Connected to DB: {}'.format(host))
        # Create cursor and execute Load SQL
        cursor = con.cursor()
        cursor.execute(select_sql)
        print('Succuessfully executed the select query.')
        rows = cursor.fetchall()
        con.close()
        new_rows = []
        for row in rows:
                if(row[1] == None):
                        new_rows.append((row[0],0))
                else:
                        new_rows.append(row)
        if(sim):
            temp1 = new_rows[-1]
            temp2 = new_rows[-2]
            temp3 = new_rows[-3]
            del new_rows[-1]
            del new_rows[-2]
            del new_rows[-3]
            new_rows.append((temp3[0],positivity))
            new_rows.append((temp2[0],positivity))
            new_rows.append((temp1[0],positivity))
        
    except Exception as e:
        print('Error: {}'.format(str(e)))
        sys.exit(1)

    numpy_array = np.array(new_rows)
    nump_array_shape = numpy_array.shape

    numpy_array[:, 0] -= np.mean(numpy_array[:, 0])
    numpy_array[:, 0] /= np.std(numpy_array[:, 0])

    tensor = torch.from_numpy(numpy_array).float()
    return tensor
# Execution Example
#load_sql = "LOAD DATA LOCAL INFILE '/home/corkboard/db_scripts/"+sys.argv[1]+"' INTO TABLE corkboard_DB.Stories FIELDS TERMINATED BY ',' ENCLOSED BY '\"' IGNORE 0 LINES;"

def create_graph(predictions, targets, ticker):
    pred_x = np.arange(predictions.shape[0])
    targ_x = np.arange(targets.shape[0])

    plt.plot(targ_x, targets, 'r-.')
    plt.plot(pred_x, predictions, 'b-.')

    plt.savefig(GRAPH_PATH + str(ticker) + '_graph.png')
    plt.close()

    #ticker = 'AAPL'
    #test_data = fetchPricesByTicker(ticker,True, 0.9)
def main(ticker, sim, positivity):

    test_data = fetchPricesByTicker(ticker,sim,positivity)
    test_data = test_data.view(1, test_data.size(0), test_data.size(1))
    test_data_size = test_data.size()
    model = LSTM()
    model.load_state_dict(torch.load(MODEL_PATH))
    model.eval()

    with torch.no_grad():
        output = model(test_data, test=True)

        np_output = output.detach().numpy()
        np_output = np.reshape(np_output, np_output.shape[1])

        target = test_data.detach().numpy()
        target = target[:, :, 0]
        target = np.reshape(target, target.shape[1])

        create_graph(np_output, target,ticker)


