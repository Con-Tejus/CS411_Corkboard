import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F
from torch import optim
import numpy as np
import matplotlib.pyplot as plt 
import json
import pandas as pd

epochs = 750
TRAINING_DATA_PATH = '/Users/john/CS411/project/lstm/time_series_data.csv'
TICKER_NAMES = ['AMD', 'SIRI']

MODEL_PATH = '/Users/john/CS411/project/lstm/'

class LSTM(nn.Module):
    def __init__(self):
        super(LSTM, self).__init__()
        self.lstm1  = nn.LSTMCell(2, 64)
        self.lstm2  = nn.LSTMCell(64, 64)
        self.fc1    = nn.Linear(64, 1)
        

    def forward(self, input, test=False):
        output = []
        h_t1 = torch.zeros(input.size(0), 64, dtype=torch.float)
        h_t2 = torch.zeros(input.size(0), 64, dtype=torch.float)
        c_t1 = torch.zeros(input.size(0), 64, dtype=torch.float)
        c_t2 = torch.zeros(input.size(0), 64, dtype=torch.float)

        final_output_price = 0
        final_output_score = torch.Tensor([1]).float()
        for i, input_t in enumerate(input.chunk(input.size(1), dim=1)):
            input_t = input_t.view(input_t.size(0), 2)
            final_output_score = input_t
            
            #print("Enumerate Input Size:", input_t.size())
            h_t1, c_t1  = self.lstm1(input_t, (h_t1, c_t1))
            h_t2, c_t2  = self.lstm2(h_t1, (h_t2, c_t2))
            curr_output = self.fc1(h_t2)

            final_output_price = curr_output
            output.append(curr_output)

        final_output_score = torch.Tensor([[final_output_score[0, 1].item()]])

        if test:
            for i in range(15):
                test_input = torch.cat((final_output_price, final_output_score), dim=1)
                h_t1, c_t1  = self.lstm1(test_input, (h_t1, c_t1))
                h_t2, c_t2  = self.lstm2(h_t1, (h_t2, c_t2))
                curr_output = self.fc1(h_t2)

                output.append(curr_output)
                final_output_price = curr_output

        output = torch.stack(output, 1)
        return output

def get_training_data(path):
    df = pd.DataFrame.from_csv(path, header=None)
    data_list = []
    for name in TICKER_NAMES:
        curr_df = df.loc[df[1] == name]
        curr_vals = curr_df[2].values
        
        curr_vals -= np.mean(curr_vals, axis=0)
        curr_vals /= np.std(curr_vals, axis=0)

        data_list.append(curr_vals)
    return np.concatenate(data_list)

def get_sent_training(data):
    data = data.detach().numpy()
    story_training_data = np.zeros(data.shape)
    for i in range(data.shape[0]):
        for j in range(data.shape[1] - 1):
            if data[i, j] - data[i, j+1] < -0.5 or data[i, j] - data[i, j+1] > 0.5:
                story_training_data[i, j] = data[i, j+1] - data[i, j]

    return story_training_data

def stack_training_data(prices, stories):
    training_data = np.zeros((prices.shape[0], prices.shape[1], 2))

    for i in range(prices.shape[0]):
        training_data[i] = np.column_stack((prices[i], stories[i]))

    return torch.from_numpy(training_data).float()
            
def split_data(data):
    num_samples = data.shape[0] // 200
    
    train_data = np.zeros((num_samples, 200))
    train_labels = np.zeros((num_samples, 200))

    for i in range(num_samples):
        base = 200 * i
        curr_train_data = data[base:(base + 200)]
        curr_train_labels = data[(base + 1):(base + 201)]

        train_data[i] = curr_train_data
        train_labels[i] = curr_train_labels

    #return train_data, train_labels

    return torch.from_numpy(train_data).float(), torch.from_numpy(train_labels).float()

def create_graph(predictions, targets, number):
    pred_x = np.arange(predictions.shape[0])
    targ_x = np.arange(targets.shape[0])

    plt.plot(targ_x, targets, 'r-.')
    plt.plot(pred_x, predictions, 'b-.')

    plt.savefig('train_graphs/' + str(number) + '.png')
    plt.close()


def train(train_data, train_labels, model, loss_func, optimizer):
    for e in range(epochs):
        model.train()

        optimizer.zero_grad()
        output = model(train_data)

        output = output.view((53, 200))

        if e % 10 == 0 or e == epochs - 1:
            create_graph(output.detach().numpy()[0], train_labels.detach().numpy()[0], e)
        
        loss = loss_func(output, train_labels)
        print("Epoch", e, "Loss:", loss.item())
        loss.backward()
        optimizer.step()

 

if __name__ == '__main__':
    data = get_training_data(TRAINING_DATA_PATH)
    train_data_prices, train_labels = split_data(data)
    
    
    story_train_data = get_sent_training(train_data_prices)
    train_data = stack_training_data(train_data_prices, story_train_data)
    
    #train_data = train_data.view(1, train_data.size(0), train_data.size(1))

    model = LSTM()
    loss_func = nn.MSELoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=0.001, momentum=0.9)

    print("Training")
    train(train_data, train_labels, model, loss_func, optimizer)

    torch.save(model.state_dict(), MODEL_PATH + 'lstm_model.pt')
    
