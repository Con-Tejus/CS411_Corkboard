from django.urls import path
from . import views

urlpatterns = [
    path('',views.index, name = 'index'),
    path('login/',views.login, name = 'login'),
    path('portfolio/',views.portfolio, name = 'portfolio'),
    path('projections/',views.projections, name = 'projections'),
    path('stories/',views.stories, name = 'stories'),
    path('simulations/',views.simulations, name = 'simulations'),
    path('signup/', views.signup.as_view(), name = 'signup')

 ]
